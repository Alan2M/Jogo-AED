#ifndef MAPA_FASES_H
#define MAPA_FASES_H
#include <stdbool.h>

bool MostrarMapaFases(void);

#endif
