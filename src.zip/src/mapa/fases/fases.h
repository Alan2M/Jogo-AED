#ifndef FASES_H
#define FASES_H

#include "../../player/player.h"
#include "raylib.h"               // garante acesso às funções gráficas

// Declaração das 5 fases do jogo
void Fase1();
void Fase2();
void Fase3();
void Fase4();
void Fase5();

#endif
