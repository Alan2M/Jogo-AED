#ifndef MENU_H
#define MENU_H

#include "raylib.h"
#include <stdbool.h>
#include <math.h>  // Necessário para fmaxf()

bool MostrarMenu(void);
void MostrarInstrucoes(void);

#endif
